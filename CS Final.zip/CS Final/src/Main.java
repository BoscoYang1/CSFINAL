// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

import java.util.Scanner;
import java.util.ArrayList;

public class Main {




        public static void main (String[]args){
            // Press Alt+Enter with your caret at the highlighted text to see how
            // IntelliJ IDEA suggests fixing it.
            ArrayList<String> Tasks = new ArrayList<String>();
            ArrayList<Integer> tasksTime = new ArrayList<Integer>();
            Scanner string1 = new Scanner(System.in);
            Scanner string2 = new Scanner(System.in);
            Scanner string3 = new Scanner(System.in);
            App_Builder Sort = new App_Builder();

            int i = 0;
            System.out.println("Do you want to sort by Longest task to Shortest task, or Shortest task to Longest task? (Use LS for Longest to Shortest and SL for Shortest to Longest)");
            String LSOrSL = string3.next();
            while (i < 1) {

                System.out.println("Enter Tasks Here (Use _ instead of Spaces)");
                Tasks.add(String.valueOf(string1.next()));
                System.out.println("Enter Tasks Time Here in Minutes ");
                tasksTime.add(string1.nextInt());
                System.out.println("More Tasks? Type Yes or No");
                String yesOrNo = string2.next();

                if (("No".equals(yesOrNo))) {
                    i = i + 1;
                }
            }
            String[] taskArray = Tasks.toArray(new String[0]);
            Integer[] taskTimeArray = tasksTime.toArray(new Integer[0]);
            if(("LS".equals(LSOrSL))){
                Sort.SortGL(taskArray,taskTimeArray);
            } else if ("SL".equals(LSOrSL)) {
                Sort.SortLG(taskArray,taskTimeArray);
            }

        }
    }
