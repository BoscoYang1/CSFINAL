public class App_Builder {
    public void SortLG(String[] sortarray1, Integer[] sortarray2) {
        for (int j = 0; j < sortarray2.length - 1; j++) {
            int minNum = j;
            int taskAccordances = j;

            for (int k = j + 1; k < sortarray2.length; k++) {
                if (sortarray2[k] < sortarray2[minNum]) {
                    minNum = k;
                    taskAccordances = k;
                }
            }
            String tempTA = sortarray1[j];
            sortarray1[j] = sortarray1[taskAccordances];
            sortarray1[taskAccordances] = tempTA;
            int temp = sortarray2[j];
            sortarray2[j] = sortarray2[minNum];
            sortarray2[minNum] = temp;
        }
        for(int g = 0; g < sortarray2.length; g++){
            System.out.println(sortarray1[g]+" " + sortarray2[g] + " Minutes");
        }
    }
    public void SortGL(String[] sortarray1, Integer[] sortarray2) {
        for (int j = 0; j < sortarray2.length - 1; j++) {
            int minNum = j;
            int taskAccordances = j;

            for (int k = j + 1; k < sortarray2.length; k++) {
                if (sortarray2[k] > sortarray2[minNum]) {
                    minNum = k;
                    taskAccordances = k;
                }
            }
            String tempTA = sortarray1[j];
            sortarray1[j] = sortarray1[taskAccordances];
            sortarray1[taskAccordances] = tempTA;
            int temp = sortarray2[j];
            sortarray2[j] = sortarray2[minNum];
            sortarray2[minNum] = temp;
        }
        for(int g = 0; g < sortarray2.length; g++){
            System.out.println(sortarray1[g]+" " + sortarray2[g] + " Minutes");
        }
    }
}
